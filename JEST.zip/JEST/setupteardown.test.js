beforeEach(() => {
  });
  
  afterEach(() => {
    
  });
  
  test('city database has Vienna', () => {
    expect('Vienna').toBeTruthy();
  });
  
  test('city database has San Juan', () => {
    expect('San Juan').toBeTruthy();
  });