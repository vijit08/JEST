test('zero', () => {
    const z = 1;
    expect(z).not.toBeNull();
    expect(z).toBeDefined();
    expect(z).not.toBeUndefined();
    //expect(z).not.toBeTruthy();
    //expect(z).toBeFalsy();
  });