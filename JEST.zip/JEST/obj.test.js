const ob = require('./object');

test('object assignment', () => {
    const data = {a: 1};
    data['b'] = 2;
    expect(data).toEqual({a: 1, b: 2});
});