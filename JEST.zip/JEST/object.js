function ob() {
    return {a:1,
    b:2}
}
module.exports = ob;